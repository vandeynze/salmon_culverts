# Purpose: Compare completeness of SubTypeName between '18 vintage and '20 vintage of PNSHP data
# Output: List of ProjectPK and WorksitePK with missing SubTypeName in '20 vintage available in '18 vintage

# Load packages ====
rm(list = ls())
library(tidyverse)

# Load data ====
setwd("C:/Users/braeden.vandeynze/Documents/Salmon Cost Project/Analysis/data") # For Braeden; comment out for other users

# '18 data
PNSHP_18 <- read_csv("./old/PNSHP_worksite-subtype.csv", guess_max = 10000) # n = 493,031

# '20 data
PNSHP_20 <- read_csv("PNSHP_worksite-subtype_20200113.csv", guess_max = 10000) # n = 118,189

# Basic cleaning ====
# Reduce '18 data to distinct worksites, eliminating VerboseName redundencies
PNSHP_18 <-
  PNSHP_18 %>%
  distinct_at(
    vars(-VerboseName),
    .keep_all = TRUE
  )
# n = 249,179

# Select relevant fields for comparison and filter to relevant years
vars_comp <- c("ProjectPK", "WorksitePK", "SubTypeName", "Completed_Year")

PNSHP_18 <-
  PNSHP_18 %>%
  rename(WorksitePK = WorkSitePK) %>%
  select(vars_comp) %>%
  filter(Completed_Year <= 2015 & Completed_Year >= 1990) %>% # n = 217,290
  distinct_all() %>% # n = 122,526
  arrange(Completed_Year, ProjectPK, WorksitePK, SubTypeName)

PNSHP_20 <-
  PNSHP_20 %>%
  select(vars_comp) %>%
  filter(Completed_Year <= 2015 & Completed_Year >= 1990) %>% # n = 98,158
  distinct_all() %>% # n = 91,721
  arrange(Completed_Year, ProjectPK, WorksitePK, SubTypeName)


# Identify missing WorksitePK and SubTypeName observations in '18 vs. '20 data ====
# Count missing values for SubTypeName, WorksitePK in both datasets
options(tibble.print_max = 50)
count_na <- function(...) sum(is.na(...))
count_na_match <- function(x, y) sum(is.na(x) & is.na(y))

PNSHP_18 %>%
  # group_by(Completed_Year) %>%
  summarize(
    n = n(),
    missing_WorksitePK = count_na(WorksitePK),
    missing_SubTypeName = count_na(SubTypeName),
    missing_both = count_na_match(WorksitePK, SubTypeName)
  )
# 77 missing both WorksitePK and SubTypeName (minimal missing values, all missingness is on same observations)

PNSHP_20 %>%
  # group_by(Completed_Year) %>%
  summarize(
    n = n(),
    missing_WorksitePK = count_na(WorksitePK),
    missing_SubTypeName = count_na(SubTypeName),
    missing_both = count_na_match(WorksitePK, SubTypeName)
  )
# 7,079 missing both WorksitePK and SubTypeName (~8% of observations); 73,909 missing SubTypeName (~80% of observations)

# ** Some projects likely added retroactively between '18 and '20 pulls in the 1990-2015 range, so a DateAdded field might be convient for QA

# Merge data <-- NEEDS TO BE DONE AT WORKSITE LEVEL, PERHAPS WITH SUBTYPENAME COUNT COMPARISON
PNSHP_comp <-
  left_join(
    PNSHP_18,
    PNSHP_20,
    by = c("ProjectPK", "WorksitePK", "Completed_Year"),
    suffix = c("_18", "_20")
  ) %>% # n = 146,115; some '18 observations with multiple matches in '20 resulting from ???
  select(-starts_with("Sub"), starts_with("Sub")) %>%
  distinct(
    ProjectPK, WorksitePK, 
  )

# Count observations with 






